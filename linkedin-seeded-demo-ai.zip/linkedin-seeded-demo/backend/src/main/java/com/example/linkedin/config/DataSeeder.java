package com.example.linkedin.config;
import com.example.linkedin.model.*;
import com.example.linkedin.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.*;
@Configuration
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {
    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() > 0) return;

        // placeholder avatars from pravatar.cc (no local files)
        String a = "https://i.pravatar.cc/150?img=1";
        String b = "https://i.pravatar.cc/150?img=2";
        String c = "https://i.pravatar.cc/150?img=3";
        String d = "https://i.pravatar.cc/150?img=4";
        String e = "https://i.pravatar.cc/150?img=5";

        AppUser alice = new AppUser("Alice Johnson","alice@example.com",passwordEncoder.encode("password"),"Software Engineer at Google",a);
        AppUser bob = new AppUser("Bob Smith","bob@example.com",passwordEncoder.encode("password"),"UX Designer at Meta",b);
        AppUser clara = new AppUser("Clara Kim","clara@example.com",passwordEncoder.encode("password"),"Product Manager at Netflix",c);
        AppUser david = new AppUser("David Lee","david@example.com",passwordEncoder.encode("password"),"DevOps Engineer at Amazon",d);
        AppUser emma = new AppUser("Emma Brown","emma@example.com",passwordEncoder.encode("password"),"Data Scientist at OpenAI",e);

        alice = userRepository.save(alice);
        bob = userRepository.save(bob);
        clara = userRepository.save(clara);
        david = userRepository.save(david);
        emma = userRepository.save(emma);

        // Connections (some mutual)
        alice.getConnections().add(bob); bob.getConnections().add(alice);
        david.getConnections().add(emma); emma.getConnections().add(david);
        clara.getConnections().add(alice); // pending-ish (we won't implement pending state)

        userRepository.saveAll(List.of(alice,bob,clara,david,emma));

        // Posts
        Post p1 = new Post(); p1.setAuthor(alice); p1.setContent("Excited to share that I just deployed a new project using Spring Boot + Angular!"); p1 = postRepository.save(p1);
        Post p2 = new Post(); p2.setAuthor(bob); p2.setContent("UI design is more than just colors and buttons—it’s communication."); p2 = postRepository.save(p2);
        Post p3 = new Post(); p3.setAuthor(emma); p3.setContent("Machine learning is only as good as the data it learns from."); p3 = postRepository.save(p3);

        // Comments
        Comment c1 = new Comment(); c1.setAuthor(bob); c1.setPost(p1); c1.setText("Looks great! Congrats 🎉"); commentRepository.save(c1);
        Comment c2 = new Comment(); c2.setAuthor(emma); c2.setPost(p1); c2.setText("Would love to see a demo!"); commentRepository.save(c2);

        // Likes
        p1.getLikes().add(bob); p1.getLikes().add(emma); postRepository.save(p1);
        p2.getLikes().add(alice); postRepository.save(p2);

        // Notifications
        Notification n1 = new Notification(); n1.setRecipient(alice); n1.setType("like"); n1.setMessage("Bob Smith liked your post."); notificationRepository.save(n1);
        Notification n2 = new Notification(); n2.setRecipient(alice); n2.setType("connection"); n2.setMessage("Clara Kim sent you a connection request."); notificationRepository.save(n2);
        Notification n3 = new Notification(); n3.setRecipient(emma); n3.setType("connection"); n3.setMessage("David Lee accepted your connection request."); notificationRepository.save(n3);
    }
}
