package com.example.linkedin.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;
import java.util.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Post {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(length = 3000) private String content;
    private LocalDateTime createdAt = LocalDateTime.now();
    @JsonIgnoreProperties({"connections","password"}) @ManyToOne private AppUser author;
    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true) private List<Comment> comments = new ArrayList<>();
    @ManyToMany @JoinTable(name = "post_likes", joinColumns = @JoinColumn(name="post_id"), inverseJoinColumns = @JoinColumn(name="user_id"))
    private Set<AppUser> likes = new HashSet<>();
}
