Backend with seeded demo data. Run via docker compose.
