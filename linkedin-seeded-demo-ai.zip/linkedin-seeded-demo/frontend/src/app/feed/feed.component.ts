import { Component } from '@angular/core';
@Component({ standalone: true, selector: 'app-feed', template: `<div class="p-6"><h2 class="text-xl">Feed</h2><p>Posts load here...</p></div>` })
export class FeedComponent {}
