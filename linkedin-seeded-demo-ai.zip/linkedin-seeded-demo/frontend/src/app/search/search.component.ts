import { Component } from '@angular/core';
@Component({ standalone: true, selector: 'app-search', template: `<div class="p-6"><h2 class="text-xl">Search</h2><p>Search results here...</p></div>` })
export class SearchComponent {}
