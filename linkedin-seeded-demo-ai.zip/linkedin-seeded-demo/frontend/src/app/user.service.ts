import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
@Injectable({ providedIn: 'root' })
export class UserService {
  private user$ = new BehaviorSubject<any>(null);
  currentUser$ = this.user$.asObservable();
  setCurrentUser(u: any) { this.user$.next(u); }
  clear() { this.user$.next(null); }
  getCurrentUser() { return this.user$.value; }
}
