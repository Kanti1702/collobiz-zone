import { Component } from '@angular/core';
@Component({ standalone: true, selector: 'app-profile', template: `<div class="p-6"><h2 class="text-xl">Profile</h2><p>User profile here...</p></div>` })
export class ProfileComponent {}
