import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { RouterModule } from '@angular/router';
import { AuthService } from './auth.service';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [MatToolbarModule, MatButtonModule, RouterModule],
  template: `
  <mat-toolbar color="primary" class="shadow-md sticky top-0 z-50">
    <div class="flex items-center justify-between w-full px-4">
      <div class="flex items-center gap-3">
        <mat-icon class="text-white">work</mat-icon>
        <span class="font-semibold text-white text-lg">LinkedIn Clone</span>
      </div>
      <div class="flex items-center gap-3">
        <a mat-button routerLink="/feed">Feed</a>
        <a mat-button routerLink="/connections">Connections</a>
        <a mat-button routerLink="/notifications">Notifications</a>
        <a mat-button routerLink="/search">Search</a>
        <a mat-button routerLink="/profile">Profile</a>
        <button mat-icon-button (click)="auth.logout()" *ngIf="auth.isLoggedIn()"><mat-icon>logout</mat-icon></button>
      </div>
    </div>
  </mat-toolbar>
  <div class="container"><router-outlet></router-outlet></div>
  `
})
export class AppComponent { constructor(public auth: AuthService){ try{ this.auth.fetchMe(); }catch(e){} } }
