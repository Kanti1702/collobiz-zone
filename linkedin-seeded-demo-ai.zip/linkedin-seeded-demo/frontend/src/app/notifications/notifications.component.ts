import { Component } from '@angular/core';
@Component({ standalone: true, selector: 'app-notifications', template: `<div class="p-6"><h2 class="text-xl">Notifications</h2><p>Notifications here...</p></div>` })
export class NotificationsComponent {}
