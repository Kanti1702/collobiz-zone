import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({ standalone: true, selector: 'app-register', template: `
<div class="mx-auto max-w-md p-6 bg-white rounded-2xl shadow-md mt-8">
  <h2 class="text-2xl font-semibold mb-4">Create account</h2>
  <form (ngSubmit)="register()">
    <input [(ngModel)]="user.fullName" name="fullName" placeholder="Full name" required class="w-full p-3 border rounded mb-3">
    <input [(ngModel)]="user.email" name="email" placeholder="Email" required class="w-full p-3 border rounded mb-3">
    <input [(ngModel)]="user.password" name="password" type="password" placeholder="Password" required class="w-full p-3 border rounded mb-3">
    <button class="w-full bg-green-600 text-white py-3 rounded">Register</button>
  </form>
</div>` })
export class RegisterComponent { user:any={}; constructor(private auth: AuthService, private router: Router){} register(){ this.auth.register(this.user).subscribe(()=> this.router.navigate(['/'])); } }
