import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
@Component({ standalone: true, selector: 'app-login', template: `
<div class="mx-auto max-w-md p-6 bg-white rounded-2xl shadow-md mt-8">
  <h2 class="text-2xl font-semibold mb-4">Welcome back</h2>
  <form (ngSubmit)="login()">
    <input [(ngModel)]="creds.email" name="email" placeholder="Email" required class="w-full p-3 border rounded mb-3">
    <input [(ngModel)]="creds.password" name="password" placeholder="Password" type="password" required class="w-full p-3 border rounded mb-3">
    <button class="w-full bg-blue-600 text-white py-3 rounded">Sign in</button>
  </form>
</div>` })
export class LoginComponent { creds:any={}; constructor(private auth: AuthService, private router: Router){} login(){ this.auth.login(this.creds).subscribe(()=> this.router.navigate(['/'])); } }
