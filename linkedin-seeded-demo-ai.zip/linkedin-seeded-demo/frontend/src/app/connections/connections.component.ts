import { Component } from '@angular/core';
@Component({ standalone: true, selector: 'app-connections', template: `<div class="p-6"><h2 class="text-xl">Connections</h2><p>Connections list here...</p></div>` })
export class ConnectionsComponent {}
