Frontend: Angular 17 standalone + Material + Tailwind (placeholders used).
