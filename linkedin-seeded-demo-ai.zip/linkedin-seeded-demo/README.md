Seeded LinkedIn demo starter
- Backend seeds demo users/posts/comments/likes/notifications on first run (if DB empty).
- Avatars use pravatar.cc placeholder URLs — no images are included in the zip.
- Dev JWT secret: devSecretKey12345
Run: docker compose up --build
