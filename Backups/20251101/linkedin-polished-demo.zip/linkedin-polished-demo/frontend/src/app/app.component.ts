import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { AuthService } from './auth.service';
import { NavbarComponent } from './navbar/navbar.component';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NavbarComponent, MatToolbarModule, MatButtonModule, MatIconModule, RouterModule],
  template: `
  <app-navbar></app-navbar>

   <div class="pt-20 px-4 sm:px-6 bg-gray-50 min-h-screen">
  <router-outlet></router-outlet>
</div>  `
})
export class AppComponent {
  constructor(public auth: AuthService) {
    // optional auto-login as demo user
    if (!this.auth.isLoggedIn()) {
      this.auth.login({ email: 'alice@example.com', password: 'password' }).subscribe({ next: () => {}, error: () => {} });
    } else {
      try{ this.auth.fetchMe(); }catch(e){}
    }
  }
}
