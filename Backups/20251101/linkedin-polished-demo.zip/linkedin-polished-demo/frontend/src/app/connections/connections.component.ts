import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
@Component({ standalone: true, 
  imports: [CommonModule],
selector: 'app-connections', template: `
<div class="max-w-3xl mx-auto p-4 space-y-6">
  <h2 class="text-2xl font-semibold mb-4">My Connections</h2>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
    <div *ngFor="let user of connections" class="bg-white p-4 rounded-2xl flex items-center justify-between hover:shadow-md transition">
      <div class="flex items-center gap-3">
        <img [src]="user.profileImageUrl || 'https://i.pravatar.cc/150?img=11'" class="w-12 h-12 rounded-full" />
        <div><div class="font-medium">{{ user.fullName }}</div><div class="text-sm text-gray-500">{{ user.headline }}</div></div>
      </div>
      <div class="flex items-center gap-2">
        <button class="px-3 py-1 border rounded">Message</button>
        <button class="px-3 py-1 bg-blue-600 text-white rounded" (click)="remove(user)">Remove</button>
      </div>
    </div>
  </div>
</div>
` })
export class ConnectionsComponent implements OnInit {
  connections:any[] = [];
  constructor(private http: HttpClient) {}
  ngOnInit(){ this.load(); }
  load(){ this.http.get<any>(environment.apiUrl  + '/connections').subscribe(res => this.connections = res?.connections || [], err=> this.connections = []); }
  remove(u:any){ this.http.post(environment.apiUrl  + `/connections/remove/${u.id}`, {}).subscribe(()=> this.load()); }
}
