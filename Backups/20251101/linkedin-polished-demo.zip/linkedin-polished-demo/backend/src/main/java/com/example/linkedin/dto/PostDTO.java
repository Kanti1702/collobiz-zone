package com.example.linkedin.dto;

import com.example.linkedin.model.Post;
import com.example.linkedin.model.AppUser;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Set;
import java.util.Map;

public record PostDTO(
        Long id,
        String content,
        String imageUrl,
        String createdAt,
        AuthorDTO author,
        Set<AppUser> likes,
        List<CommentDTO> comments
) {
    public static PostDTO fromEntity(Post post) {
        return new PostDTO(
                post.getId(),
                post.getContent(),
                post.getImageUrl(),
                post.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                new AuthorDTO(
                        post.getAuthor().getId(),
                        post.getAuthor().getFullName(),
                        post.getAuthor().getProfileImageUrl()
                ),
                post.getLikes(),
                post.getComments()
                        .stream()
                        .map(CommentDTO::fromEntity)
                        .toList()
        );
    }

    public record AuthorDTO(Long id, String fullName, String profileImageUrl) {}
}

