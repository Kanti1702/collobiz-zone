package com.example.linkedin.service;

import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class ConnectionService {

    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public Set<AppUser> getConnections(Long userId) {
        AppUser user = userRepository.findById(userId).orElseThrow();
        return user.getConnections(); // loaded inside transaction
    }
}

