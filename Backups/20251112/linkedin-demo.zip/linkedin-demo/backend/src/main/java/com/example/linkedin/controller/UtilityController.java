package com.example.linkedin.controller;

import com.example.linkedin.service.BioGeneratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/utils")
public class UtilityController {

    @Autowired
    private BioGeneratorService bioGeneratorService;

    @PostMapping("/generate-bio")
    public Map<String, String> generateBio(@RequestBody Map<String, String> payload) {
        String fullName = payload.getOrDefault("fullName", "User");
        String headline = payload.getOrDefault("headline", "");
        String bio = bioGeneratorService.generateSmartBio(fullName, headline);
        return Map.of("bio", bio);
    }
}
