package com.example.linkedin.service;

import org.springframework.stereotype.Service;
import java.util.Random;

@Service
public class BioGeneratorService {

    private static final String[] INTROS = {
        "Passionate about",
        "Driven by",
        "Dedicated to",
        "Focused on",
        "Committed to"
    };

    private static final String[] TRAITS = {
        "building impactful solutions",
        "team collaboration and innovation",
        "continuous learning and growth",
        "delivering high-quality results",
        "transforming ideas into action"
    };

    public String generateSmartBio(String fullName, String headline) {
        Random rand = new Random();
        String intro = INTROS[rand.nextInt(INTROS.length)];
        String trait = TRAITS[rand.nextInt(TRAITS.length)];
        String role = headline != null && !headline.isBlank() ? headline : "professional";

        return String.format("%s is a %s %s, %s.", fullName, intro.toLowerCase(), role, trait);
    }
}
