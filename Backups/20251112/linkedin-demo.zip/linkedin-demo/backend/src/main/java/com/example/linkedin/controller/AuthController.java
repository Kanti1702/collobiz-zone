package com.example.linkedin.controller;
import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import com.example.linkedin.security.JwtUtil;
import lombok.RequiredArgsConstructor;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder; import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
@RestController @RequestMapping("/api/auth") @RequiredArgsConstructor
public class AuthController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder; 
    private final JwtUtil jwtUtil;
    private final com.example.linkedin.service.FileStorageService fileStorageService;
    private final com.example.linkedin.service.BioGeneratorService bioGeneratorService;

    // @PostMapping("/register") public ResponseEntity<?> register(@RequestBody AppUser user) {
    //     if (userRepository.findByEmail(user.getEmail()).isPresent()) return ResponseEntity.badRequest().body(Map.of("error","Email already in use"));
    //     user.setPassword(passwordEncoder.encode(user.getPassword())); AppUser saved = userRepository.save(user);
    //     String token = jwtUtil.generateToken(saved.getEmail()); return ResponseEntity.ok(Map.of("token", token, "user", saved));
    // }
    @PostMapping("/login") public ResponseEntity<?> login(@RequestBody Map<String,String> body) {
        String email = body.get("email"); String password = body.get("password");
        Optional<AppUser> o = userRepository.findByEmail(email);
        if (o.isEmpty() || !passwordEncoder.matches(password, o.get().getPassword())) return ResponseEntity.status(401).body(Map.of("error","Invalid credentials"));
        String token = jwtUtil.generateToken(email); return ResponseEntity.ok(Map.of("token", token, "user", o.get()));
    }
    @GetMapping("/me") public ResponseEntity<?> me(@RequestHeader(name = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) return ResponseEntity.status(401).body(Map.of("error","No token"));
        String token = authHeader.substring(7); String email = jwtUtil.extractSubject(token); if (email == null) return ResponseEntity.status(401).body(Map.of("error","Invalid token"));
        return userRepository.findByEmail(email).map(u -> ResponseEntity.ok((Object)Map.of("user", u))).orElse(ResponseEntity.status(404).body((Object)Map.of("error","User not found")));
    }

    @PostMapping(value = "/register", consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
    public ResponseEntity<?> registerUser(
            @RequestPart("user") AppUser user,
            @RequestPart(value = "resume", required = false) MultipartFile resume) {

        if (resume != null && !resume.isEmpty()) {
            String resumeUrl = fileStorageService.store(resume);
            user.setResumeUrl(resumeUrl);
        }

        if (user.getBio() == null || user.getBio().isBlank()) {
            user.setBio(bioGeneratorService.generateSmartBio(user.getFullName(), user.getHeadline()));
        }

        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "User registered successfully", "user", user));
    }

}
