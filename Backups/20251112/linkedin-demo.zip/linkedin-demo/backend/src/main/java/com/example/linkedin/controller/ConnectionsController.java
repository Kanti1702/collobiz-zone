package com.example.linkedin.controller;
import com.example.linkedin.model.AppUser; import com.example.linkedin.repository.UserRepository;
import com.example.linkedin.service.ConnectionService;
import lombok.RequiredArgsConstructor; import org.springframework.http.ResponseEntity; import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*; 
import org.springframework.security.core.context.SecurityContextHolder; import java.util.*;
import com.example.linkedin.dto.ConnectionDTO;
@RestController @RequestMapping("/api/connections") @RequiredArgsConstructor
public class ConnectionsController {
    private final UserRepository userRepository;
    private final ConnectionService connectionService;

    @GetMapping public ResponseEntity<?> list() {
        //if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        //AppUser me = (AppUser) auth.getPrincipal();
    AppUser me = (AppUser) SecurityContextHolder
        .getContext()
        .getAuthentication()
        .getPrincipal();
        return ResponseEntity.ok(Map.of("connections", connectionService.getConnections(me.getId()).stream()
        .map(ConnectionDTO::fromUser)
        .toList()));
    }


    @PostMapping("/request/{targetId}") public ResponseEntity<?> request(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().add(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","requested")); }).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/accept/{targetId}") public ResponseEntity<?> accept(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().add(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","accepted")); }).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/remove/{targetId}") public ResponseEntity<?> remove(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().remove(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","removed")); }).orElse(ResponseEntity.notFound().build());
    }
}
