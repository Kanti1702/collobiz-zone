package com.example.linkedin.dto;

import com.example.linkedin.model.Comment;
import java.time.format.DateTimeFormatter;

public record CommentDTO(
        Long id,
        String text,
        String author,
        String timestamp
) {
    public static CommentDTO fromEntity(Comment c) {
        return new CommentDTO(
                c.getId(),
                c.getText(),
                c.getAuthor().getFullName(),
                c.getCreatedAt().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
        );
    }
}

