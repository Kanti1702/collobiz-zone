package com.example.linkedin.model;
import jakarta.persistence.*;
import lombok.*;
import java.time.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Notification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String type;
    private String message;
    private boolean readFlag = false;
    private LocalDateTime createdAt = LocalDateTime.now();
    @ManyToOne private AppUser recipient;
}
