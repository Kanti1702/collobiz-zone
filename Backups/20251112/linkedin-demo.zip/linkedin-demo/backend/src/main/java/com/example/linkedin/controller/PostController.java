package com.example.linkedin.controller;
import com.example.linkedin.model.AppUser; import com.example.linkedin.model.Post;
import com.example.linkedin.service.PostService;import com.example.linkedin.dto.PostDTO;
import com.example.linkedin.repository.PostRepository; import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor; import org.springframework.data.domain.Sort; import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/posts") @RequiredArgsConstructor
public class PostController {
    private final PostRepository postRepository; private final UserRepository userRepository;
    private final PostService postService;

    @GetMapping public List<PostDTO> list() { 
        //return postRepository.findAll(Sort.by(Sort.Direction.DESC, "createdAt")); 
List<Post> posts = postService.findAll();
        return posts.stream()
                .map(PostDTO::fromEntity)
                .toList();
    }

    @PostMapping public ResponseEntity<?> create(@RequestBody Map<String,Object> body, Authentication auth) {
        Long authorId = body.containsKey("authorId") ? ((Number)body.get("authorId")).longValue() : null;
        String content = (String) body.get("content");
        String imageUrl = (String) body.get("imageUrl");
        AppUser author = null;
        if (auth != null && auth.getPrincipal() instanceof AppUser) author = (AppUser) auth.getPrincipal();
        if (author == null && authorId != null) author = userRepository.findById(authorId).orElse(null);
        if (author == null) return ResponseEntity.badRequest().body(Map.of("error","author not found"));
        Post p = new Post(); p.setContent(content); p.setAuthor(author); p.setImageUrl(imageUrl); postRepository.save(p); return ResponseEntity.ok(p);
    }
    @PostMapping("/{id}/like") public ResponseEntity<?> like(@PathVariable Long id, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser user = (AppUser) auth.getPrincipal();
        Optional<Post> op = postRepository.findById(id); if (op.isEmpty()) return ResponseEntity.notFound().build();
        Post p = op.get(); if (p.getLikes().contains(user)) p.getLikes().remove(user); else p.getLikes().add(user); postRepository.save(p); return ResponseEntity.ok(p);
    }
}
