package com.example.linkedin.dto;

import com.example.linkedin.model.AppUser;

public record ConnectionDTO(Long id, String name, String headline, String avatarUrl) {
    public static ConnectionDTO fromUser(AppUser u) {
        return new ConnectionDTO(u.getId(), u.getFullName(), u.getHeadline(), u.getProfileImageUrl());
//String fullName, String email, String password, String headline, String profileImageUrl)
    }
}

