package com.example.linkedin.config;
import com.example.linkedin.model.*;
import com.example.linkedin.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import java.util.*;
import java.time.*;
@Configuration
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {
    private final UserRepository userRepository;
    private final PostRepository postRepository;
    private final CommentRepository commentRepository;
    private final NotificationRepository notificationRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() > 0) return;

        String a = "https://i.pravatar.cc/150?img=11";
        String b = "https://i.pravatar.cc/150?img=12";
        String c = "https://i.pravatar.cc/150?img=13";
        String d = "https://i.pravatar.cc/150?img=14";
        String e = "https://i.pravatar.cc/150?img=15";

        AppUser alice = new AppUser("Alice Johnson","alice@example.com",passwordEncoder.encode("password"),"Software Engineer at Google",a);
        AppUser bob = new AppUser("Bob Smith","bob@example.com",passwordEncoder.encode("password"),"UX Designer at Meta",b);
        AppUser clara = new AppUser("Clara Kim","clara@example.com",passwordEncoder.encode("password"),"Product Manager at Netflix",c);
        AppUser david = new AppUser("David Lee","david@example.com",passwordEncoder.encode("password"),"DevOps Engineer at Amazon",d);
        AppUser emma = new AppUser("Emma Brown","emma@example.com",passwordEncoder.encode("password"),"Data Scientist at OpenAI",e);

        alice = userRepository.save(alice);
        bob = userRepository.save(bob);
        clara = userRepository.save(clara);
        david = userRepository.save(david);
        emma = userRepository.save(emma);

        alice.getConnections().add(bob); bob.getConnections().add(alice);
        david.getConnections().add(emma); emma.getConnections().add(david);
        clara.getConnections().add(alice);

        userRepository.saveAll(List.of(alice,bob,clara,david,emma));

        // richer posts with unsplash images
        Post p1 = new Post(); p1.setAuthor(alice); p1.setContent("New sprint complete — team crushed it! Here's a peek at our whiteboard."); p1.setImageUrl("https://source.unsplash.com/800x400/?team,office"); p1 = postRepository.save(p1);
        Post p2 = new Post(); p2.setAuthor(bob); p2.setContent("Designing with purpose 🎨 — small wins today."); p2.setImageUrl("https://source.unsplash.com/800x400/?design,workspace"); p2 = postRepository.save(p2);
        Post p3 = new Post(); p3.setAuthor(clara); p3.setContent("Leadership is about listening and enabling others."); p3.setImageUrl("https://source.unsplash.com/800x400/?leadership,people"); p3 = postRepository.save(p3);
        Post p4 = new Post(); p4.setAuthor(david); p4.setContent("Finally automated our CI/CD pipeline — deployments are faster now!"); p4.setImageUrl("https://source.unsplash.com/800x400/?devops,cloud"); p4 = postRepository.save(p4);
        Post p5 = new Post(); p5.setAuthor(emma); p5.setContent("Data tells stories numbers alone cannot."); p5.setImageUrl("https://source.unsplash.com/800x400/?data,ai"); p5 = postRepository.save(p5);

        // comments
        commentRepository.save(new Comment(null, "Looks great! Congrats 🎉", LocalDateTime.now(), bob, p1));
        commentRepository.save(new Comment(null, "Amazing work team!", LocalDateTime.now(), clara, p1));
        commentRepository.save(new Comment(null, "Would love to collaborate", LocalDateTime.now(), emma, p2));
        commentRepository.save(new Comment(null, "Fantastic progress", LocalDateTime.now(), alice, p4));
        commentRepository.save(new Comment(null, "Insightful", LocalDateTime.now(), bob, p5));

        // likes
        p1.getLikes().add(bob); p1.getLikes().add(emma); p1.getLikes().add(clara); postRepository.save(p1);
        p2.getLikes().add(alice); p2.getLikes().add(clara); postRepository.save(p2);
        p3.getLikes().add(bob); postRepository.save(p3);
        p4.getLikes().add(alice); p4.getLikes().add(emma); postRepository.save(p4);
        p5.getLikes().add(david); postRepository.save(p5);

        // notifications
        notificationRepository.save(new Notification(null, "like", "Bob Smith liked your post.", false, java.time.LocalDateTime.now(), alice));
        notificationRepository.save(new Notification(null, "comment", "Clara Kim commented on your post.", false, java.time.LocalDateTime.now(), alice));
        notificationRepository.save(new Notification(null, "connection", "David Lee accepted your connection request.", false, java.time.LocalDateTime.now(), emma));
    }
}
