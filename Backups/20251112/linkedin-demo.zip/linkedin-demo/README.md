LinkedIn Polished Demo
- Polished frontend with animations, improved cards, and image posts (unsplash).
- Backend seeds richer demo content (images, multiple comments, likes, notifications).
- Optional auto-login: alice@example.com / password
Run:
  docker compose up --build
