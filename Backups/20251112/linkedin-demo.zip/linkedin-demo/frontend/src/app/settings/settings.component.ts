import { Component } from '@angular/core';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { CommonModule } from '@angular/common';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-settings',
  standalone: true,
  imports: [
    MatCardModule,
    MatTabsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule
  ],
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css'],
})
export class SettingsComponent {
  name = 'Alice Johnson';
  email = 'alice@example.com';
  password = '';
  avatarUrl = 'https://i.pravatar.cc/150?img=47';
  previewUrl: string | ArrayBuffer | null = null;

  // Privacy settings
  showEmail = false;
  allowMessages = true;
  shareActivity = true;

  // Notification settings
  notifyConnections = true;
  notifyLikes = true;
  notifyComments = true;
  notifyMentions = false;

  constructor(private snackBar: MatSnackBar, private http: HttpClient) {}

  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => (this.previewUrl = reader.result);
      reader.readAsDataURL(file);

      const formData = new FormData();
      formData.append('file', file);
      // Mock backend upload call
      this.http.post('/api/profile/upload', formData).subscribe({
        next: () => this.snackBar.open('Profile photo updated!', 'Close', { duration: 2000 }),
        error: () => this.snackBar.open('Upload failed', 'Close', { duration: 2000 })
      });
    }
  }

  save(section: string) {
    this.snackBar.open(`${section} settings saved successfully!`, 'Close', {
      duration: 2500,
      horizontalPosition: 'right',
      verticalPosition: 'bottom'
    });
  }
}
