import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators, FormsModule } from '@angular/forms';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSnackBarModule,
    MatIconModule,
    MatCardModule
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent {
  registerForm: FormGroup;
  resumeFile: File | null = null;
  loading = false;

  constructor(private fb: FormBuilder, private http: HttpClient, private snack: MatSnackBar) {
    this.registerForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      headline: [''],
      bio: ['']
    });
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.resumeFile = input.files[0];
    }
  }

  generateBio() {
    const fullName = this.registerForm.get('fullName')?.value;
    const headline = this.registerForm.get('headline')?.value;

    if (!fullName) {
      this.snack.open('Please enter your name first!', 'Close', { duration: 3000 });
      return;
    }

    this.loading = true;
    this.http.post<{ bio: string }>('/api/utils/generate-bio', { fullName, headline })
      .subscribe({
        next: (res) => {
          this.registerForm.patchValue({ bio: res.bio });
          this.snack.open('✨ Smart bio generated!', 'Close', { duration: 2000 });
          this.loading = false;
        },
        error: () => {
          this.snack.open('Could not generate bio', 'Close', { duration: 3000 });
          this.loading = false;
        }
      });
  }

  submit() {
    if (this.registerForm.invalid) {
      this.snack.open('Please fill all required fields', 'Close', { duration: 3000 });
      return;
    }

    const formData = new FormData();
    // Object.entries(this.registerForm.value).forEach(([key, value]) => {
    //   formData.append(key, value as string);
    // });
      formData.append('user', new Blob([JSON.stringify(this.registerForm.value)], { type: 'application/json' }));


    if (this.resumeFile) formData.append('resume', this.resumeFile,this.resumeFile.name);

    this.http.post('/api/auth/register', formData).subscribe({
      next: () => this.snack.open('✅ Registration successful!', 'Close', { duration: 3000 }),
      error: () => this.snack.open('❌ Registration failed', 'Close', { duration: 3000 })
    });
  }
}
