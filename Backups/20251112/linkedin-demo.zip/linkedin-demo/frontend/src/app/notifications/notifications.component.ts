import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
@Component({ standalone: true, 
  imports: [CommonModule],
selector: 'app-notifications', template: `
<div class="max-w-2xl mx-auto p-4 space-y-4">
  <h2 class="text-2xl font-semibold mb-4">Notifications</h2>
  <div *ngFor="let note of notifications" class="bg-white p-4 rounded-2xl hover:bg-gray-50 transition">
    <div class="flex items-start gap-3">
      <div class="p-2 rounded-full bg-blue-50"><span class="material-icons">notifications</span></div>
      <div><p class="text-gray-800">{{ note.message }}</p><p class="text-sm text-gray-500">{{ note.createdAt | date:'short' }}</p></div>
    </div>
  </div>
</div>` })
export class NotificationsComponent implements OnInit {
  notifications:any[] = [];
  constructor(private http: HttpClient) {}
  ngOnInit(){ this.http.get<any>(environment.apiUrl  + '/notifications').subscribe(res=> this.notifications = res.notifications || [] , err=> this.notifications = []); }
}
