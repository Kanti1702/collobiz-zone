package com.example.linkedin.controller;
import com.example.linkedin.model.AppUser; import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor; import org.springframework.http.ResponseEntity; import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/connections") @RequiredArgsConstructor
public class ConnectionsController {
    private final UserRepository userRepository;
    @GetMapping public ResponseEntity<?> list(Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return ResponseEntity.ok(Map.of("connections", me.getConnections()));
    }
    @PostMapping("/request/{targetId}") public ResponseEntity<?> request(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().add(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","requested")); }).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/accept/{targetId}") public ResponseEntity<?> accept(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().add(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","accepted")); }).orElse(ResponseEntity.notFound().build());
    }
    @PostMapping("/remove/{targetId}") public ResponseEntity<?> remove(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> { me.getConnections().remove(target); userRepository.save(me); return ResponseEntity.ok(Map.of("status","removed")); }).orElse(ResponseEntity.notFound().build());
    }
}
