package com.example.linkedin.controller;
import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor; import org.springframework.http.ResponseEntity; import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/users") @RequiredArgsConstructor
public class UserController {
    private final UserRepository userRepository;
    @GetMapping("/search") public ResponseEntity<?> search(@RequestParam String q) {
        List<AppUser> users = userRepository.findByFullNameContainingIgnoreCase(q);
        return ResponseEntity.ok(Map.of("users", users));
    }
    @GetMapping("/{id}") public ResponseEntity<?> getUser(@PathVariable Long id) {
        return userRepository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
}
