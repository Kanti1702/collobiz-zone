package com.example.linkedin.model;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.*;
import java.util.*;
@Entity @Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    private String fullName;
    @Column(unique = true) private String email;
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY) private String password;
    private String headline;
    @Column(length = 2000) private String about;
    private String profileImageUrl;
    @JsonIgnore
    @ManyToMany
    @JoinTable(name = "connections", joinColumns = @JoinColumn(name="user_id"), inverseJoinColumns = @JoinColumn(name="connection_id"))
    private Set<AppUser> connections = new HashSet<>();
    public AppUser(String fullName, String email, String password, String headline, String profileImageUrl) {
        this.fullName = fullName; this.email = email; this.password = password; this.headline = headline; this.profileImageUrl = profileImageUrl;
    }
}
