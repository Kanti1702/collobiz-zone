package com.example.linkedin.controller;
import com.example.linkedin.model.Notification;
import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.NotificationRepository;
import lombok.RequiredArgsConstructor; import org.springframework.http.ResponseEntity; import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/notifications") @RequiredArgsConstructor
public class NotificationsController {
    private final NotificationRepository notificationRepository;
    @GetMapping public ResponseEntity<?> list(Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        List<Notification> notes = notificationRepository.findByRecipientIdOrderByCreatedAtDesc(me.getId());
        return ResponseEntity.ok(Map.of("notifications", notes));
    }
}
