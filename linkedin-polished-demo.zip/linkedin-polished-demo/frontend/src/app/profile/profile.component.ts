import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { PostService } from '../post.service';
@Component({ standalone: true, selector: 'app-profile', template: `
<div class="max-w-3xl mx-auto mt-6">
  <div class="bg-white rounded-2xl shadow-md overflow-hidden">
    <div class="h-40 bg-cover bg-center" [style.backgroundImage]="'url(https://source.unsplash.com/1200x300/?office,abstract)'"></div>
    <div class="p-6 text-center -mt-12">
      <img [src]="user?.profileImageUrl || 'https://i.pravatar.cc/150?img=11'" class="w-28 h-28 rounded-full mx-auto mb-3 border-4 border-white shadow" />
      <h2 class="text-xl font-semibold">{{ user?.fullName }}</h2>
      <p class="text-gray-600">{{ user?.headline }}</p>
      <p class="mt-3 text-gray-700">{{ user?.about }}</p>
    </div>
  </div>

  <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
    <div class="md:col-span-2 space-y-4">
      <div class="bg-white p-4 rounded-2xl shadow-sm" *ngIf="posts?.length">
        <h3 class="text-lg font-semibold mb-3">Posts</h3>
        <div *ngFor="let p of posts" class="mb-3 border-b pb-3">
          <div class="font-medium">{{ p.content }}</div>
          <div class="text-sm text-gray-500">{{ p.createdAt | date:'short' }}</div>
        </div>
      </div>
    </div>
    <div class="space-y-4">
      <div class="bg-white p-4 rounded-2xl shadow-sm">
        <h4 class="font-semibold mb-2">Mutual Connections</h4>
        <div *ngFor="let m of mutuals" class="flex items-center gap-2 mb-2"><img [src]="m.profileImageUrl" class="w-8 h-8 rounded-full" /><div class="text-sm">{{ m.fullName }}</div></div>
      </div>
    </div>
  </div>
</div>` })
export class ProfileComponent implements OnInit {
  user:any; posts:any[] = []; mutuals:any[] = [];
  constructor(private userService: UserService, private postService: PostService){ this.userService.currentUser$.subscribe(u=> this.user=u); }
  ngOnInit(){ this.postService.list().subscribe((res:any)=> { this.posts = (res || []).filter((p:any)=> p.author?.email === this.user?.email); this.mutuals = [{ fullName: 'Bob Smith', profileImageUrl: 'https://i.pravatar.cc/150?img=12' }, { fullName: 'David Lee', profileImageUrl: 'https://i.pravatar.cc/150?img=14' }]; }); }
}
