import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { trigger, transition, style, animate, query, stagger } from '@angular/animations';
@Component({
  standalone: true,
  selector: 'app-feed',
  template: `
  <div class="max-w-2xl mx-auto p-4" [@listAnimation]>
    <h2 class="text-2xl font-semibold mb-4">Your Feed</h2>
    <div *ngIf="loading" class="text-gray-500 text-center py-4">Loading posts...</div>
    <div *ngIf="!loading && posts.length === 0" class="text-gray-500 text-center py-4">No posts yet — start connecting with others!</div>
    <div *ngFor="let post of posts" class="mb-4 bg-white p-4 card-rounded shadow-sm feed-card">
      <div class="flex items-center gap-3 mb-3">
        <img [src]="post.author?.profileImageUrl" alt="avatar" class="w-12 h-12 rounded-full shadow-sm" />
        <div>
          <div class="font-semibold text-gray-900">{{ post.author?.fullName }}</div>
          <div class="text-sm text-gray-500">{{ post.author?.headline }}</div>
        </div>
      </div>
      <p class="text-gray-800 my-2">{{ post.content }}</p>
      <img *ngIf="post.imageUrl" [src]="post.imageUrl" class="post-image my-3" />
      <div class="flex items-center justify-between text-gray-600 text-sm mt-3">
        <div class="flex items-center gap-4">
          <button class="flex items-center gap-2"><span class="material-icons">thumb_up</span><span>{{ post.likes?.length || 0 }}</span></button>
          <button class="flex items-center gap-2"><span class="material-icons">chat_bubble</span><span>{{ post.comments?.length || 0 }}</span></button>
        </div>
        <div class="text-xs text-gray-400">{{ post.createdAt | date:'short' }}</div>
      </div>
    </div>
  </div>
  `,
  animations: [
    trigger('listAnimation', [
      transition(':enter', [
        query(':enter', [
          style({ opacity: 0, transform: 'translateY(8px)' }),
          stagger(80, [animate('350ms ease-out', style({ opacity: 1, transform: 'translateY(0)' }))])
        ], { optional: true })
      ])
    ])
  ]
})
export class FeedComponent implements OnInit {
  posts:any[] = [];
  loading = true;
  constructor(private postService: PostService) {}
  ngOnInit(){ this.postService.list().subscribe({ next: data => { this.posts = data; this.loading=false; }, error: () => this.loading=false }); }
}
