import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
@Component({ imports: [FormsModule], standalone: true, selector: 'app-search', template: `
<div class="max-w-3xl mx-auto p-4">
  <div class="flex gap-2 mb-4">
    <input [(ngModel)]="query" (keyup.enter)="performSearch()" placeholder="Search people or posts..." class="w-full p-3 border rounded" />
    <button class="px-4 bg-blue-600 text-white rounded" (click)="performSearch()">Search</button>
  </div>
  <div *ngIf="results?.users?.length"><h3 class="text-lg font-semibold mb-2">People</h3><div class="space-y-2"><div *ngFor="let u of results.users" class="flex items-center gap-2 hover:bg-gray-100 p-2 rounded-lg"><img [src]="u.profileImageUrl || 'https://i.pravatar.cc/150?img=11'" class="w-10 h-10 rounded-full" /><div><div class="font-medium">{{ u.fullName }}</div><div class="text-sm text-gray-500">{{ u.headline }}</div></div></div></div>
  <div *ngIf="results?.posts?.length" class="mt-6"><h3 class="text-lg font-semibold mb-2">Posts</h3><div *ngFor="let p of results.posts" class="bg-white p-4 rounded-xl shadow-sm mb-3"><div class="font-medium">{{ p.author.fullName }}</div><p class="text-gray-800">{{ p.content }}</p><img *ngIf="p.imageUrl" [src]="p.imageUrl" class="post-image mt-2"/></div></div>
</div>` })
export class SearchComponent {
  query=''; results:any = { users: [], posts: [] };
  constructor(private http: HttpClient) {}
  performSearch(){ if(!this.query) return; this.http.get<any>(`/api/users/search?q=${encodeURIComponent(this.query)}`).subscribe(res=> this.results.users = res.users || []); /* posts search not implemented on backend */ }
}
