LinkedIn-style starter (Full Angular CLI scaffold)

What's included:
- backend/  (Spring Boot app - copied from previous starter)
- frontend/ (Real Angular CLI-style project scaffold with Tailwind integration and Auth)
- docker-compose.yml to bring up MySQL + backend + frontend (nginx)

Quickstart (requires Docker & Docker Compose):
1. Extract the zip
2. From project root run: docker compose up --build
3. Frontend: http://localhost:4200, Backend API: http://localhost:8080/api

Notes:
- The Angular app here is scaffolded to be compatible with Angular CLI. To run locally without Docker:
  - `cd frontend`
  - `npm install`
  - `npx ng serve --open`
- Tailwind is included via CDN for quick prototyping. For full Tailwind build integration, run the Angular build with PostCSS configured.
- Replace JWT secret and hard-coded/demo prompts before production.
