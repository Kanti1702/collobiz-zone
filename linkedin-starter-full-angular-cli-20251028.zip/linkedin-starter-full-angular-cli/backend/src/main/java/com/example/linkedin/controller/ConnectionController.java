package com.example.linkedin.controller;

import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/connections")
@RequiredArgsConstructor
public class ConnectionController {
    private final UserRepository userRepository;

    @PostMapping("/connect/{targetId}")
    public ResponseEntity<?> connect(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> {
            me.getConnections().add(target);
            userRepository.save(me);
            return ResponseEntity.ok(Map.of("status","connected"));
        }).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/disconnect/{targetId}")
    public ResponseEntity<?> disconnect(@PathVariable Long targetId, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(targetId).map(target -> {
            me.getConnections().remove(target);
            userRepository.save(me);
            return ResponseEntity.ok(Map.of("status","disconnected"));
        }).orElse(ResponseEntity.notFound().build());
    }

}
