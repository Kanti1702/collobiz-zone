package com.example.linkedin.controller;

import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import com.example.linkedin.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody AppUser user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error","Email already in use"));
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        AppUser saved = userRepository.save(user);
        String token = jwtUtil.generateToken(saved.getEmail());
        return ResponseEntity.ok(Map.of("token", token, "user", saved));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body) {
        String email = body.get("email");
        String password = body.get("password");
        Optional<AppUser> o = userRepository.findByEmail(email);
        if (o.isEmpty() || !passwordEncoder.matches(password, o.get().getPassword())) {
            return ResponseEntity.status(401).body(Map.of("error","Invalid credentials"));
        }
        String token = jwtUtil.generateToken(email);
        return ResponseEntity.ok(Map.of("token", token, "user", o.get()));
    }

    @GetMapping("/me")
    public ResponseEntity<?> me(@RequestHeader(name = "Authorization", required = false) String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(401).body(Map.of("error","No token"));
        }
        String token = authHeader.substring(7);
        String email = jwtUtil.extractSubject(token);
        if (email == null) return ResponseEntity.status(401).body(Map.of("error","Invalid token"));
        return userRepository.findByEmail(email)
            .map(u -> ResponseEntity.ok(u))
            .orElse(ResponseEntity.status(404).body(Map.of("error","User not found")));
    }

}
