package com.example.linkedin.controller;

import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {
    private final UserRepository userRepository;

    @GetMapping("/{id}")
    public ResponseEntity<?> getUser(@PathVariable Long id) {
        return userRepository.findById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/me")
    public ResponseEntity<?> updateMe(@RequestBody AppUser updated, Authentication auth) {
        AppUser me = (AppUser) auth.getPrincipal();
        return userRepository.findById(me.getId()).map(u -> {
            u.setFullName(updated.getFullName());
            u.setHeadline(updated.getHeadline());
            u.setAbout(updated.getAbout());
            u.setProfileImageUrl(updated.getProfileImageUrl());
            userRepository.save(u);
            return ResponseEntity.ok(u);
        }).orElse(ResponseEntity.status(404).build());
    }
}
