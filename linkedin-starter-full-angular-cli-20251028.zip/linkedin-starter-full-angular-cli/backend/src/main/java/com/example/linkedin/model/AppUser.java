package com.example.linkedin.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class AppUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    @Column(unique = true)
    private String email;
    private String password;
    private String headline;
    @Column(length = 2000)
    private String about;
    private String profileImageUrl;

    @ManyToMany
    @JoinTable(name = "connections",
        joinColumns = @JoinColumn(name="user_id"),
        inverseJoinColumns = @JoinColumn(name="connection_id"))
    private Set<AppUser> connections = new HashSet<>();
}
