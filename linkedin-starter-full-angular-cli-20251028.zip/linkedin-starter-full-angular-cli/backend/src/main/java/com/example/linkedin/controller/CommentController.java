package com.example.linkedin.controller;

import com.example.linkedin.model.Comment;
import com.example.linkedin.model.Post;
import com.example.linkedin.model.AppUser;
import com.example.linkedin.repository.CommentRepository;
import com.example.linkedin.repository.PostRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/comments")
@RequiredArgsConstructor
public class CommentController {
    private final CommentRepository commentRepository;
    private final PostRepository postRepository;

    @PostMapping("/post/{postId}")
    public ResponseEntity<?> comment(@PathVariable Long postId, @RequestBody Map<String,String> body, Authentication auth) {
        if (auth==null || !(auth.getPrincipal() instanceof AppUser)) return ResponseEntity.status(401).build();
        AppUser user = (AppUser) auth.getPrincipal();
        Optional<Post> op = postRepository.findById(postId);
        if (op.isEmpty()) return ResponseEntity.notFound().build();
        Post p = op.get();
        Comment c = new Comment();
        c.setText(body.get("text"));
        c.setAuthor(user);
        c.setPost(p);
        commentRepository.save(c);
        return ResponseEntity.ok(c);
    }
}
