# Backend (Spring Boot)

Environment:
- Expects a MySQL service named `mysql` (see docker-compose.yml)

Important env vars (can set in docker-compose):
- MYSQL_USER, MYSQL_PASSWORD
- JWT_SECRET (used to sign tokens)

Run with Docker Compose:
- `docker compose up --build` (from project root)
