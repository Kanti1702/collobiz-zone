//import { bootstrapApplication } from '@angular/platform-browser';
//import { provideRouter, withComponentInputBinding } from '@angular/router';
//import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
//import { provideAnimations } from '@angular/platform-browser/animations';
//import { AppComponent } from './app/app.component';
//import { appRoutes } from './app/app.routes';
//import { importProvidersFrom } from '@angular/core';
//import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { HTTP_INTERCEPTORS } from '@angular/common/http';
//import { AuthInterceptor } from './app/auth.interceptor';
//
//bootstrapApplication(AppComponent, {
//  providers: [
//    importProvidersFrom(BrowserAnimationsModule),
//    provideRouter(appRoutes, withComponentInputBinding()),
//    provideHttpClient(withInterceptorsFromDi()),
//    provideAnimations(),
//    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
//  ]
//}).catch(err => console.error(err));
//

import { bootstrapApplication } from '@angular/platform-browser';
import { provideRouter, withComponentInputBinding } from '@angular/router';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { provideAnimations } from '@angular/platform-browser/animations';
import { AppComponent } from './app/app.component';
import { appRoutes } from './app/app.routes';
import { importProvidersFrom } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './app/auth.interceptor';
import { AuthService } from './app/auth.service';

bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(BrowserAnimationsModule),
    provideRouter(appRoutes, withComponentInputBinding()),
    provideHttpClient(withInterceptorsFromDi()),
    provideAnimations(),
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ]
}).then(appRef => {
  // obtain AuthService from the platform injector to fetch current user
  const injector = (appRef as any)._injector ?? (appRef as any).injector;
  const auth = injector.get(AuthService);
  auth.fetchMe(); // will populate UserService.currentUser$
}).catch(err => console.error(err));

