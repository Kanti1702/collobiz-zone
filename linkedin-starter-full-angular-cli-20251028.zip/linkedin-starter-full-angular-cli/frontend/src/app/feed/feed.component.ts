import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { UserService } from '../user.service';
import { MatCardModule } from '@angular/material/card';
import { FormsModule } from '@angular/forms'; // Import FormsModule


@Component({
  standalone: true,
  selector: 'app-feed',
  template: `
  <div>
    <mat-card>
      <textarea [(ngModel)]="content" placeholder="What's on your mind?"></textarea>
      <button mat-raised-button color="primary" (click)="create()">Post</button>
    </mat-card>

    <mat-card *ngFor="let p of posts" class="mt-3">
      <div>{{p.author?.fullName}}</div>
      <div>{{p.createdAt}}</div>
      <p>{{p.content}}</p>
      <button mat-button (click)="like(p)">Like ({{p.likes?.length || 0}})</button>
      <button mat-button (click)="openComment(p)">Comment</button>
      <div *ngFor="let c of p.comments">
        <strong>{{c.author?.fullName}}</strong>: {{c.text}}
      </div>
    </mat-card>
  </div>
  `,
  imports: [MatCardModule, FormsModule]
})
export class FeedComponent implements OnInit {
  posts: any[] = [];
  content = '';

  constructor(private postService: PostService, private userService: UserService) {}

  ngOnInit() { this.load(); }

  load() { this.postService.list().subscribe((res: any[]) => this.posts = res); }

  create() {
    if(!this.content) return;
    this.postService.create(this.content).subscribe(() => { this.content = ''; this.load(); });
  }

  like(p: any) {
    this.postService.like(p.id).subscribe(() => this.load());
  }

  openComment(p: any) {
    const text = prompt('Comment:');
    if(!text) return;
    this.postService.comment(p.id, text).subscribe(()=> this.load());
  }
}

