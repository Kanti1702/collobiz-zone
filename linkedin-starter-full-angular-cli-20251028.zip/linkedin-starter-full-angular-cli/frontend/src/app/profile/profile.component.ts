import { Component } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  standalone: true,
  selector: 'app-profile',
  template: `
    <mat-card *ngIf="user">
      <h2>{{user.fullName}}</h2>
      <div>{{user.email}}</div>
      <p>{{user.about}}</p>
      <button mat-button (click)="connect()">Connect</button>
    </mat-card>
  `
})
export class ProfileComponent {
  user: any;
  constructor(private userService: UserService) {
    this.userService.currentUser$.subscribe(u => this.user = u);
  }

  connect() {
    // to connect to another user you'd call connection service endpoint with target id
    alert('Use Connections UI to connect to other users.');
  }
}

