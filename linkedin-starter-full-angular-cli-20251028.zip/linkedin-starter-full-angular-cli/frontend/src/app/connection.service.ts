import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../environments/environment';

@Injectable({ providedIn: 'root' })
export class ConnectionService {
  api = environment.apiUrl + '/connections';
  constructor(private http: HttpClient) {}

  connect(targetId: number) { return this.http.post(`${this.api}/connect/${targetId}`, {}); }
  disconnect(targetId: number) { return this.http.post(`${this.api}/disconnect/${targetId}`, {}); }
}

