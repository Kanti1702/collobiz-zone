import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';
import { UserService } from './user.service';
import { tap } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class AuthService {
  api = environment.apiUrl + '/auth';
  constructor(private http: HttpClient, private router: Router, private userService: UserService) {}

  register(user: any) {
    return this.http.post<any>(this.api + '/register', user).pipe(
      tap(res => { if (res.token) { this.setToken(res.token); this.fetchMe(); } })
    );
  }

  login(creds: any) {
    return this.http.post<any>(this.api + '/login', creds).pipe(
      tap(res => { if (res.token) { this.setToken(res.token); this.fetchMe(); } })
    );
  }

  me() {
    return this.http.get<any>(this.api + '/me');
  }

  // convenience to call and set current user
  fetchMe() {
    const token = this.getToken();
    if (!token) return;
    this.me().subscribe({
      next: user => this.userService.setCurrentUser(user),
      error: () => { this.logout(); }
    });
  }

  setToken(t: string) { localStorage.setItem('jwt', t); }
  getToken() { return localStorage.getItem('jwt'); }
  isLoggedIn() { return !!this.getToken(); }
  logout() { localStorage.removeItem('jwt'); this.userService.clear(); this.router.navigate(['/login']); }
}

