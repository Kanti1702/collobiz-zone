import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, FormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
  <mat-card class="max-w-md">
    <h2>Login</h2>
    <form (ngSubmit)="login()">
      <mat-form-field class="w-full"><input matInput placeholder="Email" [(ngModel)]="creds.email" name="email"></mat-form-field>
      <mat-form-field class="w-full"><input matInput placeholder="Password" [(ngModel)]="creds.password" name="password" type="password"></mat-form-field>
      <button mat-raised-button color="primary" type="submit">Login</button>
    </form>
  </mat-card>
  `
})
export class LoginComponent {
  creds:any = {};
  constructor(private auth: AuthService, private router: Router) {}
  login(){ this.auth.login(this.creds).subscribe((res:any)=>{ if(res.token) this.auth.setToken(res.token); this.router.navigate(['/']); }); }
}
