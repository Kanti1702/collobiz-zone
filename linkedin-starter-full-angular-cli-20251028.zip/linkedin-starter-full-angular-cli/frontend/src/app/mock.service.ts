import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class MockService {
  getPosts() {
    return [
      {
        id: 1,
        content: 'Welcome to your network! This is a mock post.',
        author: { fullName: 'Alice Johnson' },
        createdAt: new Date().toISOString(),
        likes: [],
        comments: [
          { id: 1, text: 'Great!', author: { fullName: 'Bob' } }
        ]
      },
      {
        id: 2,
        content: 'Second mock post to seed the feed.',
        author: { fullName: 'Charlie' },
        createdAt: new Date().toISOString(),
        likes: [],
        comments: []
      }
    ];
  }
}
