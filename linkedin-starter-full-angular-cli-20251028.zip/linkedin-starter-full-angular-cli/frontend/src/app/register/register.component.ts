import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  standalone: true,
  selector: 'app-register',
  imports: [CommonModule, FormsModule, MatCardModule, MatFormFieldModule, MatInputModule, MatButtonModule],
  template: `
  <mat-card class="max-w-md">
    <h2>Register</h2>
    <form (ngSubmit)="register()">
      <mat-form-field class="w-full"><input matInput placeholder="Full name" [(ngModel)]="user.fullName" name="fullName"></mat-form-field>
      <mat-form-field class="w-full"><input matInput placeholder="Email" [(ngModel)]="user.email" name="email"></mat-form-field>
      <mat-form-field class="w-full"><input matInput placeholder="Password" [(ngModel)]="user.password" name="password" type="password"></mat-form-field>
      <button mat-raised-button color="primary" type="submit">Register</button>
    </form>
  </mat-card>
  `
})
export class RegisterComponent {
  user:any = {};
  constructor(private auth: AuthService, private router: Router) {}
  register(){ this.auth.register(this.user).subscribe((res:any)=>{ if(res.token) this.auth.setToken(res.token); this.router.navigate(['/']); }); }
}
