import { Component } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { RouterModule } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [MatToolbarModule, MatButtonModule, MatCardModule, RouterModule],
  template: `
  <mat-toolbar color="primary">
    <span>LinkedIn Clone</span>
    <span style="flex:1 1 auto"></span>
    <button mat-button *ngIf="!auth.isLoggedIn()" routerLink="/login">Login</button>
    <button mat-button *ngIf="!auth.isLoggedIn()" routerLink="/register">Register</button>
    <button mat-button *ngIf="auth.isLoggedIn()" routerLink="/">Feed</button>
    <button mat-button *ngIf="auth.isLoggedIn()" routerLink="/profile">Profile</button>
    <button mat-button *ngIf="auth.isLoggedIn()" (click)="auth.logout()">Logout</button>
  </mat-toolbar>
  <div class="container">
    <router-outlet></router-outlet>
  </div>
  `
})
export class AppComponent {
  constructor(public auth: AuthService) {}
}
