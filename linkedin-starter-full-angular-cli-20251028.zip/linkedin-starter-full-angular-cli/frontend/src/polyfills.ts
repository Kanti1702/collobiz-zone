// Polyfills for modern browsers
import 'zone.js';  // this is required for Angular run-time 

