Angular 17 standalone starter with Angular Material (mock data included)

Quickstart:
1. npm install
2. ng serve --open (or npm start)

Notes:
- This is a minimal standalone-based Angular app for demo. Angular Material components are used.
- Auth calls go to /api/* (proxy should be configured in dev server or via nginx in Docker)
